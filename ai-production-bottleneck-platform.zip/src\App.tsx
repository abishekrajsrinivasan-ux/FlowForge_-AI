import React from 'react';
import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ProductionDataProvider } from './context/ProductionDataContext';
import { AppLayout } from './components/layout/AppLayout';

import { LoginPage } from './pages/LoginPage';
import { Overview } from './pages/Overview';
import { OeeProduction } from './pages/OeeProduction';
import { BottleneckIntelligence } from './pages/BottleneckIntelligence';
import { RootCauseExplorer } from './pages/RootCauseExplorer';
import { LossAnalysis } from './pages/LossAnalysis';
import { TargetRisk } from './pages/TargetRisk';
import { WhatIfSimulator } from './pages/WhatIfSimulator';
import { ProductionRiskRadar } from './pages/ProductionRiskRadar';
import { ActionCenter } from './pages/ActionCenter';
import { ImprovementTracking } from './pages/ImprovementTracking';
import { DataManagement } from './pages/DataManagement';
import { Settings } from './pages/Settings';

// Authentication guard
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center text-slate-300 font-mono text-xs">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-blue-500 animate-ping" />
          <span>Authenticating FactoryFlow terminal...</span>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return <>{children}</>;
};

// Login Route guard (if already logged in, redirect to dashboard)
const PublicAuthRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return null;
  }

  if (isAuthenticated) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
};

export const App: React.FC = () => {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ProductionDataProvider>
          <Routes>
            {/* Public Login Route - accessible anytime for sign-in or switching accounts */}
            <Route path="/login" element={<LoginPage />} />

            {/* Protected Dashboard Routes */}
            <Route
              element={
                <ProtectedRoute>
                  <AppLayout />
                </ProtectedRoute>
              }
            >
              <Route path="/" element={<Overview />} />
              <Route path="/oee" element={<OeeProduction />} />
              <Route path="/bottlenecks" element={<BottleneckIntelligence />} />
              <Route path="/root-causes" element={<RootCauseExplorer />} />
              <Route path="/losses" element={<LossAnalysis />} />
              <Route path="/target-risk" element={<TargetRisk />} />
              <Route path="/simulator" element={<WhatIfSimulator />} />
              <Route path="/risk-radar" element={<ProductionRiskRadar />} />
              <Route path="/ai-insights" element={<Navigate to="/risk-radar" replace />} />
              <Route path="/actions" element={<ActionCenter />} />
              <Route path="/improvements" element={<ImprovementTracking />} />
              <Route path="/data-management" element={<DataManagement />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Route>
          </Routes>
        </ProductionDataProvider>
      </AuthProvider>
    </BrowserRouter>
  );
};

export default App;
