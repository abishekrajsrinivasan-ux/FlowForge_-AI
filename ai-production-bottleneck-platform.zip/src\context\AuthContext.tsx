import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { getSupabase, onSupabaseConfigChanged } from '../lib/supabase';

export interface AppUser {
  id: string;
  email: string;
  name: string;
  role: string;
  avatar?: string;
}

interface AuthContextType {
  user: AppUser | null;
  supabaseUser: User | null;
  session: Session | null;
  loading: boolean;
  signIn: (email: string, pass: string) => Promise<{ error: Error | null }>;
  signInDemo: (account: { email: string; name: string; role: string }) => void;
  signInWithGoogle: () => Promise<{ error: Error | null }>;
  signInWithGoogleDirect: (email: string, name?: string) => void;
  signUp: (email: string, pass: string, name?: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
  isSupabaseConfigured: boolean;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const LOCAL_USER_STORAGE_KEY = 'ff_auth_user';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [supabase, setSupabase] = useState(() => getSupabase());
  const [supabaseUser, setSupabaseUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  // App User: either mapped from Supabase or loaded from local session
  const [user, setUser] = useState<AppUser | null>(() => {
    try {
      const stored = localStorage.getItem(LOCAL_USER_STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.error('Failed to parse local auth user:', e);
    }
    return null;
  });

  const isSupabaseConfigured = Boolean(supabase);

  useEffect(() => onSupabaseConfigChanged(() => setSupabase(getSupabase())), []);

  useEffect(() => {
    if (!supabase) {
      setLoading(false);
      return;
    }

    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setSupabaseUser(session?.user ?? null);
      if (session?.user) {
        const email = session.user.email || 'user@factoryflow.ai';
        const name =
          session.user.user_metadata?.full_name ||
          session.user.user_metadata?.name ||
          email.split('@')[0];
        const role = session.user.user_metadata?.role || 'Operations Specialist';
        const appUser: AppUser = {
          id: session.user.id,
          email,
          name,
          role,
        };
        setUser(appUser);
        localStorage.setItem(LOCAL_USER_STORAGE_KEY, JSON.stringify(appUser));
      }
      setLoading(false);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      setSupabaseUser(session?.user ?? null);
      if (session?.user) {
        const email = session.user.email || 'user@factoryflow.ai';
        const name =
          session.user.user_metadata?.full_name ||
          session.user.user_metadata?.name ||
          email.split('@')[0];
        const role = session.user.user_metadata?.role || 'Operations Specialist';
        const appUser: AppUser = {
          id: session.user.id,
          email,
          name,
          role,
        };
        setUser(appUser);
        localStorage.setItem(LOCAL_USER_STORAGE_KEY, JSON.stringify(appUser));
      } else if (!localStorage.getItem(LOCAL_USER_STORAGE_KEY)) {
        setUser(null);
      }
      setLoading(false);
    });

    return () => subscription.unsubscribe();
  }, [supabase]);

  // Demo 1-click login
  const signInDemo = (account: { email: string; name: string; role: string }) => {
    const demoUser: AppUser = {
      id: `demo_${Date.now()}`,
      email: account.email,
      name: account.name,
      role: account.role,
    };
    setUser(demoUser);
    localStorage.setItem(LOCAL_USER_STORAGE_KEY, JSON.stringify(demoUser));
  };

  // Sign in with Email / Password
  const signIn = async (email: string, pass: string) => {
    if (supabase) {
      try {
        const { data, error } = await supabase.auth.signInWithPassword({
          email,
          password: pass,
        });
        if (error) return { error: new Error(error.message) };
        if (data.user) {
          const appUser: AppUser = {
            id: data.user.id,
            email: data.user.email || email,
            name: data.user.user_metadata?.full_name || email.split('@')[0],
            role: data.user.user_metadata?.role || 'Plant Engineer',
          };
          setUser(appUser);
          localStorage.setItem(LOCAL_USER_STORAGE_KEY, JSON.stringify(appUser));
        }
        return { error: null };
      } catch (err: any) {
        return { error: new Error(err.message || 'Authentication failed') };
      }
    }

    // Local / Offline authentication fallback
    if (!email || !pass) {
      return { error: new Error('Please enter both email and password.') };
    }

    // Accept valid format for local login
    const appUser: AppUser = {
      id: `usr_${Date.now()}`,
      email,
      name: email.split('@')[0].replace(/[._-]/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
      role: email.toLowerCase().includes('director')
        ? 'Plant Operations Director'
        : email.toLowerCase().includes('kaizen')
        ? 'Continuous Improvement Lead'
        : 'Industrial Operations Engineer',
    };
    setUser(appUser);
    localStorage.setItem(LOCAL_USER_STORAGE_KEY, JSON.stringify(appUser));
    return { error: null };
  };

  // Sign in with Google via Supabase OAuth
  const signInWithGoogle = async (): Promise<{ error: Error | null }> => {
    if (!supabase) {
      return { error: new Error('Google Sign-In requires Supabase to be configured. Please set up Supabase in Settings.') };
    }
    try {
      const { error } = await supabase.auth.signInWithOAuth({
        provider: 'google',
        options: {
          redirectTo: `${window.location.origin}/`,
          queryParams: {
            access_type: 'offline',
            prompt: 'consent',
          },
        },
      });
      if (error) return { error: new Error(error.message) };
      return { error: null };
    } catch (err: any) {
      return { error: new Error(err.message || 'Google Sign-In failed. Verify Supabase OAuth configuration.') };
    }
  };

  // Sign up
  const signUp = async (email: string, pass: string, name?: string) => {
    if (supabase) {
      try {
        const { data, error } = await supabase.auth.signUp({
          email,
          password: pass,
          options: {
            data: { full_name: name || email.split('@')[0] },
          },
        });
        if (error) return { error: new Error(error.message) };
        if (data.user) {
          const appUser: AppUser = {
            id: data.user.id,
            email: data.user.email || email,
            name: name || email.split('@')[0],
            role: 'Operations Specialist',
          };
          setUser(appUser);
          localStorage.setItem(LOCAL_USER_STORAGE_KEY, JSON.stringify(appUser));
        }
        return { error: null };
      } catch (err: any) {
        return { error: new Error(err.message || 'Registration failed') };
      }
    }

    // Local fallback signup
    const appUser: AppUser = {
      id: `usr_${Date.now()}`,
      email,
      name: name || email.split('@')[0],
      role: 'Operations Specialist',
    };
    setUser(appUser);
    localStorage.setItem(LOCAL_USER_STORAGE_KEY, JSON.stringify(appUser));
    return { error: null };
  };

  // Direct Google/Gmail sign in
  const signInWithGoogleDirect = (email: string, name?: string) => {
    const formattedName =
      name ||
      email
        .split('@')[0]
        .replace(/[._-]/g, ' ')
        .replace(/\b\w/g, (c) => c.toUpperCase());
    const googleUser: AppUser = {
      id: `google_${Date.now()}`,
      email,
      name: formattedName,
      role: 'Operations Engineer',
      avatar: undefined,
    };
    setUser(googleUser);
    localStorage.setItem(LOCAL_USER_STORAGE_KEY, JSON.stringify(googleUser));
  };

  // Sign out
  const signOut = async () => {
    if (supabase) {
      try {
        await supabase.auth.signOut();
      } catch (e) {
        console.warn('Supabase signOut error:', e);
      }
    }
    setUser(null);
    setSupabaseUser(null);
    setSession(null);
    localStorage.removeItem(LOCAL_USER_STORAGE_KEY);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        supabaseUser,
        session,
        loading,
        signIn,
        signInDemo,
        signInWithGoogle,
        signInWithGoogleDirect,
        signUp,
        signOut,
        isSupabaseConfigured,
        isAuthenticated: Boolean(user),
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
